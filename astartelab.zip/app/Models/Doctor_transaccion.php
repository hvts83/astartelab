<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Doctor_transaccion extends Model
{
  protected $table = "doctor_transacciones";
}
