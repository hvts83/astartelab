<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Citologia_diagnostico extends Model
{
    protected $table = "citologia_diagnostico";
}
