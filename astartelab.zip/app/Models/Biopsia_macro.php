<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Biopsia_macro extends Model
{
    protected $table = "biopsia_macro";
}
