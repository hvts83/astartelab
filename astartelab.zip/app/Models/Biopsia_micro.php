<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Biopsia_micro extends Model
{
    protected $table = "biopsia_micro";
}
