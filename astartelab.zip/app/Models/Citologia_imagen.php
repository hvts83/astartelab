<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Citologia_imagen extends Model
{
  protected $table = "citologia_imagen";
}
