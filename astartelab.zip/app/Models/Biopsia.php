<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Biopsia extends Model
{
  protected $table = "biopsias";
}
