<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Consulta_transacciones extends Model
{
  protected $table = "consultas_transacciones";
}
