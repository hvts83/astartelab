<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Cuenta_transaccion extends Model
{
  protected $table = "cuenta_transacciones";
}
