<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Biopsia_preliminar extends Model
{
    protected $table = "biopsia_preliminar";
}
