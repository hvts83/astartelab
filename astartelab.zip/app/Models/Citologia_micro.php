<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Citologia_micro extends Model
{
    protected $table = "citologia_micro";
}
